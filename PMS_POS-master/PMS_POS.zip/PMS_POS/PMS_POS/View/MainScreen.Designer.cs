﻿namespace PMS_POS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.ReservacionesDropDown = new System.Windows.Forms.Panel();
            this.btnRegistroHabitaciones = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.DropDownProductos = new System.Windows.Forms.Panel();
            this.btnRegistroProducto = new System.Windows.Forms.Button();
            this.btnRegistrarCompra = new System.Windows.Forms.Button();
            this.btnVentasPorCategoria = new System.Windows.Forms.Button();
            this.btnHistorialCompra = new System.Windows.Forms.Button();
            this.btnListaProductos = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panelClientes = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.btnListadoClientes = new System.Windows.Forms.Button();
            this.btnRegistroHuesped = new System.Windows.Forms.Button();
            this.panelProveedores = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.btnListadoProveedores = new System.Windows.Forms.Button();
            this.btnRegistroProveedores = new System.Windows.Forms.Button();
            this.panelReportesFinancieros = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.btnDetallesIngresosExtras = new System.Windows.Forms.Button();
            this.btnCuentasPorHospedaje = new System.Windows.Forms.Button();
            this.btnImpuestos = new System.Windows.Forms.Button();
            this.btnDescuentosRealizados = new System.Windows.Forms.Button();
            this.btnFacturas = new System.Windows.Forms.Button();
            this.btnReservacionesCanceladas = new System.Windows.Forms.Button();
            this.btnIngresosDía = new System.Windows.Forms.Button();
            this.btnResumenDía = new System.Windows.Forms.Button();
            this.btnDescuentosRegistradosHoy = new System.Windows.Forms.Button();
            this.btnEgresosDía = new System.Windows.Forms.Button();
            this.panelControlUsuarios = new System.Windows.Forms.Panel();
            this.btnNuevoEmpleado = new System.Windows.Forms.Button();
            this.btnListadoEmpleados = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.panelConfiguracion = new System.Windows.Forms.Panel();
            this.button27 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.btnPermisosUsuarios = new System.Windows.Forms.Button();
            this.btnConfigurarImpuestos = new System.Windows.Forms.Button();
            this.btnConfigurarTipoCategoria = new System.Windows.Forms.Button();
            this.btnTipoRubroProveedores = new System.Windows.Forms.Button();
            this.btnTipoHabitaciones = new System.Windows.Forms.Button();
            this.btnTipoDocumento = new System.Windows.Forms.Button();
            this.btnInformacionCompania = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.btnPuntoDeVenta = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.SidePanel = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.timer5 = new System.Windows.Forms.Timer(this.components);
            this.timer6 = new System.Windows.Forms.Timer(this.components);
            this.timer7 = new System.Windows.Forms.Timer(this.components);
            this.userControlInicio1 = new PMS_POS.View.UserControlInicio();
            this.panel1.SuspendLayout();
            this.ReservacionesDropDown.SuspendLayout();
            this.DropDownProductos.SuspendLayout();
            this.panelClientes.SuspendLayout();
            this.panelProveedores.SuspendLayout();
            this.panelReportesFinancieros.SuspendLayout();
            this.panelControlUsuarios.SuspendLayout();
            this.panelConfiguracion.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.panel1.Controls.Add(this.ReservacionesDropDown);
            this.panel1.Controls.Add(this.DropDownProductos);
            this.panel1.Controls.Add(this.panelClientes);
            this.panel1.Controls.Add(this.panelProveedores);
            this.panel1.Controls.Add(this.panelReportesFinancieros);
            this.panel1.Controls.Add(this.panelControlUsuarios);
            this.panel1.Controls.Add(this.panelConfiguracion);
            this.panel1.Controls.Add(this.btnPuntoDeVenta);
            this.panel1.Controls.Add(this.button10);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.SidePanel);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(154, 774);
            this.panel1.TabIndex = 0;
            // 
            // ReservacionesDropDown
            // 
            this.ReservacionesDropDown.Controls.Add(this.btnRegistroHabitaciones);
            this.ReservacionesDropDown.Controls.Add(this.button13);
            this.ReservacionesDropDown.Controls.Add(this.button12);
            this.ReservacionesDropDown.Controls.Add(this.button2);
            this.ReservacionesDropDown.Location = new System.Drawing.Point(4, 181);
            this.ReservacionesDropDown.MaximumSize = new System.Drawing.Size(146, 109);
            this.ReservacionesDropDown.MinimumSize = new System.Drawing.Size(146, 32);
            this.ReservacionesDropDown.Name = "ReservacionesDropDown";
            this.ReservacionesDropDown.Size = new System.Drawing.Size(146, 32);
            this.ReservacionesDropDown.TabIndex = 13;
            // 
            // btnRegistroHabitaciones
            // 
            this.btnRegistroHabitaciones.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnRegistroHabitaciones.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRegistroHabitaciones.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegistroHabitaciones.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnRegistroHabitaciones.FlatAppearance.BorderSize = 0;
            this.btnRegistroHabitaciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistroHabitaciones.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistroHabitaciones.ForeColor = System.Drawing.Color.White;
            this.btnRegistroHabitaciones.Location = new System.Drawing.Point(0, 82);
            this.btnRegistroHabitaciones.Name = "btnRegistroHabitaciones";
            this.btnRegistroHabitaciones.Size = new System.Drawing.Size(146, 25);
            this.btnRegistroHabitaciones.TabIndex = 15;
            this.btnRegistroHabitaciones.Text = "Registro Habitaciones";
            this.btnRegistroHabitaciones.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnRegistroHabitaciones.UseVisualStyleBackColor = false;
            this.btnRegistroHabitaciones.Click += new System.EventHandler(this.BtnRegistroHabitaciones_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button13.Dock = System.Windows.Forms.DockStyle.Top;
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(0, 57);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(146, 25);
            this.button13.TabIndex = 14;
            this.button13.Text = "Nueva Reservación";
            this.button13.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.Button13_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button12.Dock = System.Windows.Forms.DockStyle.Top;
            this.button12.FlatAppearance.BorderSize = 0;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.Location = new System.Drawing.Point(0, 32);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(146, 25);
            this.button12.TabIndex = 13;
            this.button12.Text = "Listado Reservaciones";
            this.button12.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.Button12_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Dock = System.Windows.Forms.DockStyle.Top;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(0, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(146, 32);
            this.button2.TabIndex = 2;
            this.button2.Text = "Reservaciones";
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // DropDownProductos
            // 
            this.DropDownProductos.Controls.Add(this.btnRegistroProducto);
            this.DropDownProductos.Controls.Add(this.btnRegistrarCompra);
            this.DropDownProductos.Controls.Add(this.btnVentasPorCategoria);
            this.DropDownProductos.Controls.Add(this.btnHistorialCompra);
            this.DropDownProductos.Controls.Add(this.btnListaProductos);
            this.DropDownProductos.Controls.Add(this.button4);
            this.DropDownProductos.Location = new System.Drawing.Point(8, 270);
            this.DropDownProductos.MaximumSize = new System.Drawing.Size(146, 145);
            this.DropDownProductos.MinimumSize = new System.Drawing.Size(146, 32);
            this.DropDownProductos.Name = "DropDownProductos";
            this.DropDownProductos.Size = new System.Drawing.Size(146, 32);
            this.DropDownProductos.TabIndex = 3;
            // 
            // btnRegistroProducto
            // 
            this.btnRegistroProducto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnRegistroProducto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRegistroProducto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegistroProducto.FlatAppearance.BorderSize = 0;
            this.btnRegistroProducto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistroProducto.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistroProducto.ForeColor = System.Drawing.Color.White;
            this.btnRegistroProducto.Location = new System.Drawing.Point(0, 32);
            this.btnRegistroProducto.Name = "btnRegistroProducto";
            this.btnRegistroProducto.Size = new System.Drawing.Size(146, 25);
            this.btnRegistroProducto.TabIndex = 12;
            this.btnRegistroProducto.Text = "Registro productos";
            this.btnRegistroProducto.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnRegistroProducto.UseVisualStyleBackColor = false;
            this.btnRegistroProducto.Click += new System.EventHandler(this.BtnRegistroProducto_Click);
            // 
            // btnRegistrarCompra
            // 
            this.btnRegistrarCompra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnRegistrarCompra.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRegistrarCompra.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegistrarCompra.FlatAppearance.BorderSize = 0;
            this.btnRegistrarCompra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistrarCompra.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrarCompra.ForeColor = System.Drawing.Color.White;
            this.btnRegistrarCompra.Location = new System.Drawing.Point(0, 99);
            this.btnRegistrarCompra.Name = "btnRegistrarCompra";
            this.btnRegistrarCompra.Size = new System.Drawing.Size(146, 25);
            this.btnRegistrarCompra.TabIndex = 11;
            this.btnRegistrarCompra.Text = "Registrar compra";
            this.btnRegistrarCompra.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnRegistrarCompra.UseVisualStyleBackColor = false;
            this.btnRegistrarCompra.Click += new System.EventHandler(this.BtnRegistrarCompra_Click);
            // 
            // btnVentasPorCategoria
            // 
            this.btnVentasPorCategoria.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnVentasPorCategoria.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnVentasPorCategoria.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVentasPorCategoria.FlatAppearance.BorderSize = 0;
            this.btnVentasPorCategoria.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVentasPorCategoria.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVentasPorCategoria.ForeColor = System.Drawing.Color.White;
            this.btnVentasPorCategoria.Location = new System.Drawing.Point(0, 75);
            this.btnVentasPorCategoria.Name = "btnVentasPorCategoria";
            this.btnVentasPorCategoria.Size = new System.Drawing.Size(146, 25);
            this.btnVentasPorCategoria.TabIndex = 10;
            this.btnVentasPorCategoria.Text = "Ventas por categoria";
            this.btnVentasPorCategoria.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnVentasPorCategoria.UseVisualStyleBackColor = false;
            this.btnVentasPorCategoria.Click += new System.EventHandler(this.BtnVentasPorCategoria_Click);
            // 
            // btnHistorialCompra
            // 
            this.btnHistorialCompra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnHistorialCompra.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnHistorialCompra.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHistorialCompra.FlatAppearance.BorderSize = 0;
            this.btnHistorialCompra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHistorialCompra.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHistorialCompra.ForeColor = System.Drawing.Color.White;
            this.btnHistorialCompra.Location = new System.Drawing.Point(0, 120);
            this.btnHistorialCompra.Name = "btnHistorialCompra";
            this.btnHistorialCompra.Size = new System.Drawing.Size(146, 25);
            this.btnHistorialCompra.TabIndex = 9;
            this.btnHistorialCompra.Text = "Historial compra";
            this.btnHistorialCompra.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnHistorialCompra.UseVisualStyleBackColor = false;
            this.btnHistorialCompra.Click += new System.EventHandler(this.BtnHistorialCompra_Click);
            // 
            // btnListaProductos
            // 
            this.btnListaProductos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnListaProductos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnListaProductos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnListaProductos.FlatAppearance.BorderSize = 0;
            this.btnListaProductos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnListaProductos.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnListaProductos.ForeColor = System.Drawing.Color.White;
            this.btnListaProductos.Location = new System.Drawing.Point(0, 54);
            this.btnListaProductos.Name = "btnListaProductos";
            this.btnListaProductos.Size = new System.Drawing.Size(146, 25);
            this.btnListaProductos.TabIndex = 6;
            this.btnListaProductos.Text = "Lista de productos";
            this.btnListaProductos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnListaProductos.UseVisualStyleBackColor = false;
            this.btnListaProductos.Click += new System.EventHandler(this.BtnListaProductos_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.Dock = System.Windows.Forms.DockStyle.Top;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(0, 0);
            this.button4.MinimumSize = new System.Drawing.Size(146, 32);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(146, 32);
            this.button4.TabIndex = 4;
            this.button4.Text = "Productos";
            this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // panelClientes
            // 
            this.panelClientes.Controls.Add(this.button5);
            this.panelClientes.Controls.Add(this.btnListadoClientes);
            this.panelClientes.Controls.Add(this.btnRegistroHuesped);
            this.panelClientes.Location = new System.Drawing.Point(6, 313);
            this.panelClientes.MaximumSize = new System.Drawing.Size(147, 82);
            this.panelClientes.MinimumSize = new System.Drawing.Size(147, 34);
            this.panelClientes.Name = "panelClientes";
            this.panelClientes.Size = new System.Drawing.Size(147, 34);
            this.panelClientes.TabIndex = 3;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.Dock = System.Windows.Forms.DockStyle.Top;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(0, 0);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(147, 36);
            this.button5.TabIndex = 5;
            this.button5.Text = "Clientes";
            this.button5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.Button5_Click);
            // 
            // btnListadoClientes
            // 
            this.btnListadoClientes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnListadoClientes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnListadoClientes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnListadoClientes.FlatAppearance.BorderSize = 0;
            this.btnListadoClientes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnListadoClientes.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnListadoClientes.ForeColor = System.Drawing.Color.White;
            this.btnListadoClientes.Location = new System.Drawing.Point(0, 57);
            this.btnListadoClientes.Name = "btnListadoClientes";
            this.btnListadoClientes.Size = new System.Drawing.Size(146, 25);
            this.btnListadoClientes.TabIndex = 7;
            this.btnListadoClientes.Text = "Listado Clientes";
            this.btnListadoClientes.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnListadoClientes.UseVisualStyleBackColor = false;
            this.btnListadoClientes.Click += new System.EventHandler(this.BtnListadoClientes_Click);
            // 
            // btnRegistroHuesped
            // 
            this.btnRegistroHuesped.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnRegistroHuesped.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRegistroHuesped.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegistroHuesped.FlatAppearance.BorderSize = 0;
            this.btnRegistroHuesped.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistroHuesped.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistroHuesped.ForeColor = System.Drawing.Color.White;
            this.btnRegistroHuesped.Location = new System.Drawing.Point(1, 36);
            this.btnRegistroHuesped.Name = "btnRegistroHuesped";
            this.btnRegistroHuesped.Size = new System.Drawing.Size(146, 25);
            this.btnRegistroHuesped.TabIndex = 6;
            this.btnRegistroHuesped.Text = "Registro Huésped";
            this.btnRegistroHuesped.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnRegistroHuesped.UseVisualStyleBackColor = false;
            this.btnRegistroHuesped.Click += new System.EventHandler(this.BtnRegistroHuesped_Click);
            // 
            // panelProveedores
            // 
            this.panelProveedores.Controls.Add(this.button6);
            this.panelProveedores.Controls.Add(this.btnListadoProveedores);
            this.panelProveedores.Controls.Add(this.btnRegistroProveedores);
            this.panelProveedores.Location = new System.Drawing.Point(4, 363);
            this.panelProveedores.MaximumSize = new System.Drawing.Size(148, 80);
            this.panelProveedores.MinimumSize = new System.Drawing.Size(148, 32);
            this.panelProveedores.Name = "panelProveedores";
            this.panelProveedores.Size = new System.Drawing.Size(148, 32);
            this.panelProveedores.TabIndex = 11;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.Dock = System.Windows.Forms.DockStyle.Top;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.SystemColors.Window;
            this.button6.Location = new System.Drawing.Point(0, 0);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(148, 32);
            this.button6.TabIndex = 6;
            this.button6.Text = "Proveedores";
            this.button6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.Button6_Click);
            // 
            // btnListadoProveedores
            // 
            this.btnListadoProveedores.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnListadoProveedores.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnListadoProveedores.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnListadoProveedores.FlatAppearance.BorderSize = 0;
            this.btnListadoProveedores.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnListadoProveedores.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnListadoProveedores.ForeColor = System.Drawing.Color.White;
            this.btnListadoProveedores.Location = new System.Drawing.Point(0, 57);
            this.btnListadoProveedores.Name = "btnListadoProveedores";
            this.btnListadoProveedores.Size = new System.Drawing.Size(148, 25);
            this.btnListadoProveedores.TabIndex = 10;
            this.btnListadoProveedores.Text = "Listado Proveedores";
            this.btnListadoProveedores.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnListadoProveedores.UseVisualStyleBackColor = false;
            this.btnListadoProveedores.Click += new System.EventHandler(this.BtnListadoProveedores_Click);
            // 
            // btnRegistroProveedores
            // 
            this.btnRegistroProveedores.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnRegistroProveedores.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRegistroProveedores.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegistroProveedores.FlatAppearance.BorderSize = 0;
            this.btnRegistroProveedores.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegistroProveedores.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistroProveedores.ForeColor = System.Drawing.Color.White;
            this.btnRegistroProveedores.Location = new System.Drawing.Point(0, 32);
            this.btnRegistroProveedores.Name = "btnRegistroProveedores";
            this.btnRegistroProveedores.Size = new System.Drawing.Size(148, 25);
            this.btnRegistroProveedores.TabIndex = 9;
            this.btnRegistroProveedores.Text = "Registro Proveedores";
            this.btnRegistroProveedores.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnRegistroProveedores.UseVisualStyleBackColor = false;
            this.btnRegistroProveedores.Click += new System.EventHandler(this.BtnRegistroProveedores_Click);
            // 
            // panelReportesFinancieros
            // 
            this.panelReportesFinancieros.Controls.Add(this.button7);
            this.panelReportesFinancieros.Controls.Add(this.btnDetallesIngresosExtras);
            this.panelReportesFinancieros.Controls.Add(this.btnCuentasPorHospedaje);
            this.panelReportesFinancieros.Controls.Add(this.btnImpuestos);
            this.panelReportesFinancieros.Controls.Add(this.btnDescuentosRealizados);
            this.panelReportesFinancieros.Controls.Add(this.btnFacturas);
            this.panelReportesFinancieros.Controls.Add(this.btnReservacionesCanceladas);
            this.panelReportesFinancieros.Controls.Add(this.btnIngresosDía);
            this.panelReportesFinancieros.Controls.Add(this.btnResumenDía);
            this.panelReportesFinancieros.Controls.Add(this.btnDescuentosRegistradosHoy);
            this.panelReportesFinancieros.Controls.Add(this.btnEgresosDía);
            this.panelReportesFinancieros.Location = new System.Drawing.Point(4, 413);
            this.panelReportesFinancieros.MaximumSize = new System.Drawing.Size(147, 254);
            this.panelReportesFinancieros.MinimumSize = new System.Drawing.Size(147, 30);
            this.panelReportesFinancieros.Name = "panelReportesFinancieros";
            this.panelReportesFinancieros.Size = new System.Drawing.Size(147, 30);
            this.panelReportesFinancieros.TabIndex = 3;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.Dock = System.Windows.Forms.DockStyle.Top;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(0, 0);
            this.button7.MinimumSize = new System.Drawing.Size(148, 30);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(148, 30);
            this.button7.TabIndex = 7;
            this.button7.Text = "Reportes financieros";
            this.button7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.Button7_Click);
            // 
            // btnDetallesIngresosExtras
            // 
            this.btnDetallesIngresosExtras.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnDetallesIngresosExtras.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDetallesIngresosExtras.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDetallesIngresosExtras.FlatAppearance.BorderSize = 0;
            this.btnDetallesIngresosExtras.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDetallesIngresosExtras.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDetallesIngresosExtras.ForeColor = System.Drawing.Color.White;
            this.btnDetallesIngresosExtras.Location = new System.Drawing.Point(1, 234);
            this.btnDetallesIngresosExtras.Name = "btnDetallesIngresosExtras";
            this.btnDetallesIngresosExtras.Size = new System.Drawing.Size(146, 25);
            this.btnDetallesIngresosExtras.TabIndex = 17;
            this.btnDetallesIngresosExtras.Text = "Ingresos extras";
            this.btnDetallesIngresosExtras.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDetallesIngresosExtras.UseVisualStyleBackColor = false;
            this.btnDetallesIngresosExtras.Click += new System.EventHandler(this.BtnDetallesIngresosExtras_Click);
            // 
            // btnCuentasPorHospedaje
            // 
            this.btnCuentasPorHospedaje.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCuentasPorHospedaje.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCuentasPorHospedaje.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCuentasPorHospedaje.FlatAppearance.BorderSize = 0;
            this.btnCuentasPorHospedaje.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCuentasPorHospedaje.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCuentasPorHospedaje.ForeColor = System.Drawing.Color.White;
            this.btnCuentasPorHospedaje.Location = new System.Drawing.Point(1, 212);
            this.btnCuentasPorHospedaje.Name = "btnCuentasPorHospedaje";
            this.btnCuentasPorHospedaje.Size = new System.Drawing.Size(146, 25);
            this.btnCuentasPorHospedaje.TabIndex = 16;
            this.btnCuentasPorHospedaje.Text = "Cuentas por hospedaje";
            this.btnCuentasPorHospedaje.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnCuentasPorHospedaje.UseVisualStyleBackColor = false;
            this.btnCuentasPorHospedaje.Click += new System.EventHandler(this.BtnCuentasPorHospedaje_Click);
            // 
            // btnImpuestos
            // 
            this.btnImpuestos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnImpuestos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnImpuestos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnImpuestos.FlatAppearance.BorderSize = 0;
            this.btnImpuestos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImpuestos.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImpuestos.ForeColor = System.Drawing.Color.White;
            this.btnImpuestos.Location = new System.Drawing.Point(1, 169);
            this.btnImpuestos.Name = "btnImpuestos";
            this.btnImpuestos.Size = new System.Drawing.Size(146, 25);
            this.btnImpuestos.TabIndex = 15;
            this.btnImpuestos.Text = "Impuestos";
            this.btnImpuestos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnImpuestos.UseVisualStyleBackColor = false;
            this.btnImpuestos.Click += new System.EventHandler(this.BtnImpuestos_Click);
            // 
            // btnDescuentosRealizados
            // 
            this.btnDescuentosRealizados.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnDescuentosRealizados.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDescuentosRealizados.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDescuentosRealizados.FlatAppearance.BorderSize = 0;
            this.btnDescuentosRealizados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDescuentosRealizados.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDescuentosRealizados.ForeColor = System.Drawing.Color.White;
            this.btnDescuentosRealizados.Location = new System.Drawing.Point(1, 146);
            this.btnDescuentosRealizados.Name = "btnDescuentosRealizados";
            this.btnDescuentosRealizados.Size = new System.Drawing.Size(146, 25);
            this.btnDescuentosRealizados.TabIndex = 14;
            this.btnDescuentosRealizados.Text = "Descuentos realizados";
            this.btnDescuentosRealizados.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDescuentosRealizados.UseVisualStyleBackColor = false;
            this.btnDescuentosRealizados.Click += new System.EventHandler(this.BtnDescuentosRealizados_Click);
            // 
            // btnFacturas
            // 
            this.btnFacturas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnFacturas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnFacturas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFacturas.FlatAppearance.BorderSize = 0;
            this.btnFacturas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFacturas.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFacturas.ForeColor = System.Drawing.Color.White;
            this.btnFacturas.Location = new System.Drawing.Point(1, 190);
            this.btnFacturas.Name = "btnFacturas";
            this.btnFacturas.Size = new System.Drawing.Size(146, 25);
            this.btnFacturas.TabIndex = 13;
            this.btnFacturas.Text = "Facturas";
            this.btnFacturas.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnFacturas.UseVisualStyleBackColor = false;
            this.btnFacturas.Click += new System.EventHandler(this.BtnFacturas_Click);
            // 
            // btnReservacionesCanceladas
            // 
            this.btnReservacionesCanceladas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnReservacionesCanceladas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnReservacionesCanceladas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReservacionesCanceladas.FlatAppearance.BorderSize = 0;
            this.btnReservacionesCanceladas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReservacionesCanceladas.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReservacionesCanceladas.ForeColor = System.Drawing.Color.White;
            this.btnReservacionesCanceladas.Location = new System.Drawing.Point(1, 122);
            this.btnReservacionesCanceladas.Name = "btnReservacionesCanceladas";
            this.btnReservacionesCanceladas.Size = new System.Drawing.Size(146, 25);
            this.btnReservacionesCanceladas.TabIndex = 12;
            this.btnReservacionesCanceladas.Text = "Reservaciones canceladas";
            this.btnReservacionesCanceladas.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnReservacionesCanceladas.UseVisualStyleBackColor = false;
            this.btnReservacionesCanceladas.Click += new System.EventHandler(this.BtnReservacionesCanceladas_Click);
            // 
            // btnIngresosDía
            // 
            this.btnIngresosDía.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnIngresosDía.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnIngresosDía.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnIngresosDía.FlatAppearance.BorderSize = 0;
            this.btnIngresosDía.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIngresosDía.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIngresosDía.ForeColor = System.Drawing.Color.White;
            this.btnIngresosDía.Location = new System.Drawing.Point(0, 28);
            this.btnIngresosDía.Name = "btnIngresosDía";
            this.btnIngresosDía.Size = new System.Drawing.Size(146, 25);
            this.btnIngresosDía.TabIndex = 11;
            this.btnIngresosDía.Text = "Ingresos del día";
            this.btnIngresosDía.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnIngresosDía.UseVisualStyleBackColor = false;
            this.btnIngresosDía.Click += new System.EventHandler(this.BtnIngresosDía_Click);
            // 
            // btnResumenDía
            // 
            this.btnResumenDía.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnResumenDía.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnResumenDía.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnResumenDía.FlatAppearance.BorderSize = 0;
            this.btnResumenDía.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnResumenDía.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResumenDía.ForeColor = System.Drawing.Color.White;
            this.btnResumenDía.Location = new System.Drawing.Point(1, 97);
            this.btnResumenDía.Name = "btnResumenDía";
            this.btnResumenDía.Size = new System.Drawing.Size(146, 25);
            this.btnResumenDía.TabIndex = 10;
            this.btnResumenDía.Text = "Resumen del día";
            this.btnResumenDía.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnResumenDía.UseVisualStyleBackColor = false;
            this.btnResumenDía.Click += new System.EventHandler(this.BtnResumenDía_Click);
            // 
            // btnDescuentosRegistradosHoy
            // 
            this.btnDescuentosRegistradosHoy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnDescuentosRegistradosHoy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnDescuentosRegistradosHoy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDescuentosRegistradosHoy.FlatAppearance.BorderSize = 0;
            this.btnDescuentosRegistradosHoy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDescuentosRegistradosHoy.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDescuentosRegistradosHoy.ForeColor = System.Drawing.Color.White;
            this.btnDescuentosRegistradosHoy.Location = new System.Drawing.Point(1, 72);
            this.btnDescuentosRegistradosHoy.Name = "btnDescuentosRegistradosHoy";
            this.btnDescuentosRegistradosHoy.Size = new System.Drawing.Size(146, 25);
            this.btnDescuentosRegistradosHoy.TabIndex = 9;
            this.btnDescuentosRegistradosHoy.Text = "Descuentos registrados hoy";
            this.btnDescuentosRegistradosHoy.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDescuentosRegistradosHoy.UseVisualStyleBackColor = false;
            this.btnDescuentosRegistradosHoy.Click += new System.EventHandler(this.BtnDescuentosRegistradosHoy_Click);
            // 
            // btnEgresosDía
            // 
            this.btnEgresosDía.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnEgresosDía.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnEgresosDía.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEgresosDía.FlatAppearance.BorderSize = 0;
            this.btnEgresosDía.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEgresosDía.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEgresosDía.ForeColor = System.Drawing.Color.White;
            this.btnEgresosDía.Location = new System.Drawing.Point(1, 51);
            this.btnEgresosDía.Name = "btnEgresosDía";
            this.btnEgresosDía.Size = new System.Drawing.Size(146, 25);
            this.btnEgresosDía.TabIndex = 8;
            this.btnEgresosDía.Text = "Egresos del día";
            this.btnEgresosDía.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnEgresosDía.UseVisualStyleBackColor = false;
            this.btnEgresosDía.Click += new System.EventHandler(this.BtnEgresosDía_Click);
            // 
            // panelControlUsuarios
            // 
            this.panelControlUsuarios.Controls.Add(this.btnNuevoEmpleado);
            this.panelControlUsuarios.Controls.Add(this.btnListadoEmpleados);
            this.panelControlUsuarios.Controls.Add(this.button8);
            this.panelControlUsuarios.Location = new System.Drawing.Point(6, 496);
            this.panelControlUsuarios.MaximumSize = new System.Drawing.Size(148, 80);
            this.panelControlUsuarios.MinimumSize = new System.Drawing.Size(148, 32);
            this.panelControlUsuarios.Name = "panelControlUsuarios";
            this.panelControlUsuarios.Size = new System.Drawing.Size(148, 32);
            this.panelControlUsuarios.TabIndex = 3;
            // 
            // btnNuevoEmpleado
            // 
            this.btnNuevoEmpleado.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnNuevoEmpleado.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnNuevoEmpleado.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNuevoEmpleado.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNuevoEmpleado.FlatAppearance.BorderSize = 0;
            this.btnNuevoEmpleado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNuevoEmpleado.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevoEmpleado.ForeColor = System.Drawing.Color.White;
            this.btnNuevoEmpleado.Location = new System.Drawing.Point(0, 57);
            this.btnNuevoEmpleado.Name = "btnNuevoEmpleado";
            this.btnNuevoEmpleado.Size = new System.Drawing.Size(148, 25);
            this.btnNuevoEmpleado.TabIndex = 10;
            this.btnNuevoEmpleado.Text = "Nuevo Empleado";
            this.btnNuevoEmpleado.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnNuevoEmpleado.UseVisualStyleBackColor = false;
            this.btnNuevoEmpleado.Click += new System.EventHandler(this.BtnNuevoEmpleado_Click);
            // 
            // btnListadoEmpleados
            // 
            this.btnListadoEmpleados.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnListadoEmpleados.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnListadoEmpleados.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnListadoEmpleados.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnListadoEmpleados.FlatAppearance.BorderSize = 0;
            this.btnListadoEmpleados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnListadoEmpleados.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnListadoEmpleados.ForeColor = System.Drawing.Color.White;
            this.btnListadoEmpleados.Location = new System.Drawing.Point(0, 32);
            this.btnListadoEmpleados.Name = "btnListadoEmpleados";
            this.btnListadoEmpleados.Size = new System.Drawing.Size(148, 25);
            this.btnListadoEmpleados.TabIndex = 9;
            this.btnListadoEmpleados.Text = "Listado de Empleados";
            this.btnListadoEmpleados.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnListadoEmpleados.UseVisualStyleBackColor = false;
            this.btnListadoEmpleados.Click += new System.EventHandler(this.BtnListadoEmpleados_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button8.Dock = System.Windows.Forms.DockStyle.Top;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(0, 0);
            this.button8.MinimumSize = new System.Drawing.Size(148, 30);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(148, 32);
            this.button8.TabIndex = 8;
            this.button8.Text = "Control de Usuarios";
            this.button8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.Button8_Click);
            // 
            // panelConfiguracion
            // 
            this.panelConfiguracion.Controls.Add(this.button27);
            this.panelConfiguracion.Controls.Add(this.button26);
            this.panelConfiguracion.Controls.Add(this.button25);
            this.panelConfiguracion.Controls.Add(this.button24);
            this.panelConfiguracion.Controls.Add(this.button23);
            this.panelConfiguracion.Controls.Add(this.button22);
            this.panelConfiguracion.Controls.Add(this.button21);
            this.panelConfiguracion.Controls.Add(this.btnPermisosUsuarios);
            this.panelConfiguracion.Controls.Add(this.btnConfigurarImpuestos);
            this.panelConfiguracion.Controls.Add(this.btnConfigurarTipoCategoria);
            this.panelConfiguracion.Controls.Add(this.btnTipoRubroProveedores);
            this.panelConfiguracion.Controls.Add(this.btnTipoHabitaciones);
            this.panelConfiguracion.Controls.Add(this.btnTipoDocumento);
            this.panelConfiguracion.Controls.Add(this.btnInformacionCompania);
            this.panelConfiguracion.Controls.Add(this.button9);
            this.panelConfiguracion.Location = new System.Drawing.Point(4, 551);
            this.panelConfiguracion.MaximumSize = new System.Drawing.Size(153, 209);
            this.panelConfiguracion.MinimumSize = new System.Drawing.Size(153, 32);
            this.panelConfiguracion.Name = "panelConfiguracion";
            this.panelConfiguracion.Size = new System.Drawing.Size(153, 32);
            this.panelConfiguracion.TabIndex = 3;
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button27.Cursor = System.Windows.Forms.Cursors.Default;
            this.button27.Dock = System.Windows.Forms.DockStyle.Top;
            this.button27.FlatAppearance.BorderSize = 0;
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button27.ForeColor = System.Drawing.Color.White;
            this.button27.Location = new System.Drawing.Point(0, 357);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(153, 25);
            this.button27.TabIndex = 24;
            this.button27.Text = "Configuracion";
            this.button27.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button27.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button26.Cursor = System.Windows.Forms.Cursors.Default;
            this.button26.Dock = System.Windows.Forms.DockStyle.Top;
            this.button26.FlatAppearance.BorderSize = 0;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button26.ForeColor = System.Drawing.Color.White;
            this.button26.Location = new System.Drawing.Point(0, 332);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(153, 25);
            this.button26.TabIndex = 23;
            this.button26.Text = "Configuracion";
            this.button26.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button26.UseVisualStyleBackColor = false;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button25.Cursor = System.Windows.Forms.Cursors.Default;
            this.button25.Dock = System.Windows.Forms.DockStyle.Top;
            this.button25.FlatAppearance.BorderSize = 0;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button25.ForeColor = System.Drawing.Color.White;
            this.button25.Location = new System.Drawing.Point(0, 307);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(153, 25);
            this.button25.TabIndex = 22;
            this.button25.Text = "Configuracion";
            this.button25.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button25.UseVisualStyleBackColor = false;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button24.Cursor = System.Windows.Forms.Cursors.Default;
            this.button24.Dock = System.Windows.Forms.DockStyle.Top;
            this.button24.FlatAppearance.BorderSize = 0;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.ForeColor = System.Drawing.Color.White;
            this.button24.Location = new System.Drawing.Point(0, 282);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(153, 25);
            this.button24.TabIndex = 21;
            this.button24.Text = "Configuracion";
            this.button24.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button24.UseVisualStyleBackColor = false;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button23.Cursor = System.Windows.Forms.Cursors.Default;
            this.button23.Dock = System.Windows.Forms.DockStyle.Top;
            this.button23.FlatAppearance.BorderSize = 0;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.ForeColor = System.Drawing.Color.White;
            this.button23.Location = new System.Drawing.Point(0, 257);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(153, 25);
            this.button23.TabIndex = 20;
            this.button23.Text = "Configuracion";
            this.button23.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button23.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button22.Cursor = System.Windows.Forms.Cursors.Default;
            this.button22.Dock = System.Windows.Forms.DockStyle.Top;
            this.button22.FlatAppearance.BorderSize = 0;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.ForeColor = System.Drawing.Color.White;
            this.button22.Location = new System.Drawing.Point(0, 232);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(153, 25);
            this.button22.TabIndex = 19;
            this.button22.Text = "Configuracion";
            this.button22.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button22.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button21.Cursor = System.Windows.Forms.Cursors.Default;
            this.button21.Dock = System.Windows.Forms.DockStyle.Top;
            this.button21.FlatAppearance.BorderSize = 0;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.ForeColor = System.Drawing.Color.White;
            this.button21.Location = new System.Drawing.Point(0, 207);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(153, 25);
            this.button21.TabIndex = 18;
            this.button21.Text = "Configuracion";
            this.button21.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button21.UseVisualStyleBackColor = false;
            // 
            // btnPermisosUsuarios
            // 
            this.btnPermisosUsuarios.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnPermisosUsuarios.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnPermisosUsuarios.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnPermisosUsuarios.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPermisosUsuarios.FlatAppearance.BorderSize = 0;
            this.btnPermisosUsuarios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPermisosUsuarios.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPermisosUsuarios.ForeColor = System.Drawing.Color.White;
            this.btnPermisosUsuarios.Location = new System.Drawing.Point(0, 182);
            this.btnPermisosUsuarios.Name = "btnPermisosUsuarios";
            this.btnPermisosUsuarios.Size = new System.Drawing.Size(153, 25);
            this.btnPermisosUsuarios.TabIndex = 17;
            this.btnPermisosUsuarios.Text = "PermisosUsuarios";
            this.btnPermisosUsuarios.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnPermisosUsuarios.UseVisualStyleBackColor = false;
            this.btnPermisosUsuarios.Click += new System.EventHandler(this.BtnPermisosUsuarios_Click);
            // 
            // btnConfigurarImpuestos
            // 
            this.btnConfigurarImpuestos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnConfigurarImpuestos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnConfigurarImpuestos.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnConfigurarImpuestos.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnConfigurarImpuestos.FlatAppearance.BorderSize = 0;
            this.btnConfigurarImpuestos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfigurarImpuestos.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfigurarImpuestos.ForeColor = System.Drawing.Color.White;
            this.btnConfigurarImpuestos.Location = new System.Drawing.Point(0, 157);
            this.btnConfigurarImpuestos.Name = "btnConfigurarImpuestos";
            this.btnConfigurarImpuestos.Size = new System.Drawing.Size(153, 25);
            this.btnConfigurarImpuestos.TabIndex = 16;
            this.btnConfigurarImpuestos.Text = "Configurar impuestos";
            this.btnConfigurarImpuestos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnConfigurarImpuestos.UseVisualStyleBackColor = false;
            this.btnConfigurarImpuestos.Click += new System.EventHandler(this.BtnConfigurarImpuestos_Click);
            // 
            // btnConfigurarTipoCategoria
            // 
            this.btnConfigurarTipoCategoria.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnConfigurarTipoCategoria.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnConfigurarTipoCategoria.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnConfigurarTipoCategoria.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnConfigurarTipoCategoria.FlatAppearance.BorderSize = 0;
            this.btnConfigurarTipoCategoria.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfigurarTipoCategoria.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfigurarTipoCategoria.ForeColor = System.Drawing.Color.White;
            this.btnConfigurarTipoCategoria.Location = new System.Drawing.Point(0, 132);
            this.btnConfigurarTipoCategoria.Name = "btnConfigurarTipoCategoria";
            this.btnConfigurarTipoCategoria.Size = new System.Drawing.Size(153, 25);
            this.btnConfigurarTipoCategoria.TabIndex = 15;
            this.btnConfigurarTipoCategoria.Text = "Tipo de Categoria";
            this.btnConfigurarTipoCategoria.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnConfigurarTipoCategoria.UseVisualStyleBackColor = false;
            this.btnConfigurarTipoCategoria.Click += new System.EventHandler(this.BtnConfigurarTipoCategoria_Click);
            // 
            // btnTipoRubroProveedores
            // 
            this.btnTipoRubroProveedores.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnTipoRubroProveedores.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnTipoRubroProveedores.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnTipoRubroProveedores.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTipoRubroProveedores.FlatAppearance.BorderSize = 0;
            this.btnTipoRubroProveedores.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTipoRubroProveedores.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTipoRubroProveedores.ForeColor = System.Drawing.Color.White;
            this.btnTipoRubroProveedores.Location = new System.Drawing.Point(0, 107);
            this.btnTipoRubroProveedores.Name = "btnTipoRubroProveedores";
            this.btnTipoRubroProveedores.Size = new System.Drawing.Size(153, 25);
            this.btnTipoRubroProveedores.TabIndex = 14;
            this.btnTipoRubroProveedores.Text = "Tipo Rubro de Proveedores";
            this.btnTipoRubroProveedores.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTipoRubroProveedores.UseVisualStyleBackColor = false;
            this.btnTipoRubroProveedores.Click += new System.EventHandler(this.BtnTipoRubroProveedores_Click);
            // 
            // btnTipoHabitaciones
            // 
            this.btnTipoHabitaciones.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnTipoHabitaciones.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnTipoHabitaciones.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnTipoHabitaciones.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTipoHabitaciones.FlatAppearance.BorderSize = 0;
            this.btnTipoHabitaciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTipoHabitaciones.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTipoHabitaciones.ForeColor = System.Drawing.Color.White;
            this.btnTipoHabitaciones.Location = new System.Drawing.Point(0, 82);
            this.btnTipoHabitaciones.Name = "btnTipoHabitaciones";
            this.btnTipoHabitaciones.Size = new System.Drawing.Size(153, 25);
            this.btnTipoHabitaciones.TabIndex = 13;
            this.btnTipoHabitaciones.Text = "Tipo de Habitaciones";
            this.btnTipoHabitaciones.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTipoHabitaciones.UseVisualStyleBackColor = false;
            this.btnTipoHabitaciones.Click += new System.EventHandler(this.BtnTipoHabitaciones_Click);
            // 
            // btnTipoDocumento
            // 
            this.btnTipoDocumento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnTipoDocumento.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnTipoDocumento.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnTipoDocumento.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnTipoDocumento.FlatAppearance.BorderSize = 0;
            this.btnTipoDocumento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTipoDocumento.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTipoDocumento.ForeColor = System.Drawing.Color.White;
            this.btnTipoDocumento.Location = new System.Drawing.Point(0, 57);
            this.btnTipoDocumento.Name = "btnTipoDocumento";
            this.btnTipoDocumento.Size = new System.Drawing.Size(153, 25);
            this.btnTipoDocumento.TabIndex = 12;
            this.btnTipoDocumento.Text = "Tipo de Documento";
            this.btnTipoDocumento.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTipoDocumento.UseVisualStyleBackColor = false;
            this.btnTipoDocumento.Click += new System.EventHandler(this.BtnTipoDocumento_Click);
            // 
            // btnInformacionCompania
            // 
            this.btnInformacionCompania.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnInformacionCompania.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnInformacionCompania.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnInformacionCompania.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnInformacionCompania.FlatAppearance.BorderSize = 0;
            this.btnInformacionCompania.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInformacionCompania.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInformacionCompania.ForeColor = System.Drawing.Color.White;
            this.btnInformacionCompania.Location = new System.Drawing.Point(0, 32);
            this.btnInformacionCompania.Name = "btnInformacionCompania";
            this.btnInformacionCompania.Size = new System.Drawing.Size(153, 25);
            this.btnInformacionCompania.TabIndex = 10;
            this.btnInformacionCompania.Text = "Información Compañía";
            this.btnInformacionCompania.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnInformacionCompania.UseVisualStyleBackColor = false;
            this.btnInformacionCompania.Click += new System.EventHandler(this.BtnInformacionCompania_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button9.Cursor = System.Windows.Forms.Cursors.Default;
            this.button9.Dock = System.Windows.Forms.DockStyle.Top;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(0, 0);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(153, 32);
            this.button9.TabIndex = 9;
            this.button9.Text = "Configuracion";
            this.button9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.Button9_Click);
            // 
            // btnPuntoDeVenta
            // 
            this.btnPuntoDeVenta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnPuntoDeVenta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPuntoDeVenta.FlatAppearance.BorderSize = 0;
            this.btnPuntoDeVenta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPuntoDeVenta.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPuntoDeVenta.ForeColor = System.Drawing.Color.White;
            this.btnPuntoDeVenta.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPuntoDeVenta.Location = new System.Drawing.Point(5, 450);
            this.btnPuntoDeVenta.Name = "btnPuntoDeVenta";
            this.btnPuntoDeVenta.Size = new System.Drawing.Size(146, 32);
            this.btnPuntoDeVenta.TabIndex = 14;
            this.btnPuntoDeVenta.Text = "Punto de Venta";
            this.btnPuntoDeVenta.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnPuntoDeVenta.UseVisualStyleBackColor = true;
            this.btnPuntoDeVenta.Click += new System.EventHandler(this.BtnPuntoDeVenta_Click);
            // 
            // button10
            // 
            this.button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(11, 232);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(135, 32);
            this.button10.TabIndex = 11;
            this.button10.Text = "Habitaciones";
            this.button10.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.Button10_Click_1);
            // 
            // panel5
            // 
            this.panel5.Location = new System.Drawing.Point(153, 89);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(960, 516);
            this.panel5.TabIndex = 3;
            // 
            // SidePanel
            // 
            this.SidePanel.BackColor = System.Drawing.Color.RoyalBlue;
            this.SidePanel.Location = new System.Drawing.Point(0, 111);
            this.SidePanel.Name = "SidePanel";
            this.SidePanel.Size = new System.Drawing.Size(12, 32);
            this.SidePanel.TabIndex = 10;
            // 
            // button3
            // 
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(5, 195);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(0, 0);
            this.button3.TabIndex = 3;
            this.button3.Text = "Punto de Venta";
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // button1
            // 
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(1, 111);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(146, 32);
            this.button1.TabIndex = 1;
            this.button1.Text = "Inicio";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(28, 5);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(93, 84);
            this.panel3.TabIndex = 1;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel3_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(24, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Logo";
            this.label1.Click += new System.EventHandler(this.Label1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(154, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1077, 29);
            this.panel2.TabIndex = 0;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel2_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1041, 7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(19, 16);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.PictureBox1_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(154, 29);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1077, 58);
            this.panel4.TabIndex = 2;
            // 
            // timer1
            // 
            this.timer1.Interval = 15;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick_1);
            // 
            // timer2
            // 
            this.timer2.Interval = 15;
            this.timer2.Tick += new System.EventHandler(this.Timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Interval = 15;
            this.timer3.Tick += new System.EventHandler(this.Timer3_Tick);
            // 
            // timer4
            // 
            this.timer4.Interval = 15;
            this.timer4.Tick += new System.EventHandler(this.Timer4_Tick);
            // 
            // timer5
            // 
            this.timer5.Interval = 15;
            this.timer5.Tick += new System.EventHandler(this.Timer5_Tick);
            // 
            // timer6
            // 
            this.timer6.Interval = 15;
            this.timer6.Tick += new System.EventHandler(this.Timer6_Tick);
            // 
            // timer7
            // 
            this.timer7.Interval = 15;
            this.timer7.Tick += new System.EventHandler(this.Timer7_Tick);
            // 
            // userControlInicio1
            // 
            this.userControlInicio1.BackColor = System.Drawing.SystemColors.Menu;
            this.userControlInicio1.Location = new System.Drawing.Point(279, 91);
            this.userControlInicio1.Name = "userControlInicio1";
            this.userControlInicio1.Size = new System.Drawing.Size(1062, 692);
            this.userControlInicio1.TabIndex = 1;
            this.userControlInicio1.Load += new System.EventHandler(this.UserControlInicio1_Load);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Menu;
            this.ClientSize = new System.Drawing.Size(1231, 774);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.userControlInicio1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.panel1.ResumeLayout(false);
            this.ReservacionesDropDown.ResumeLayout(false);
            this.DropDownProductos.ResumeLayout(false);
            this.panelClientes.ResumeLayout(false);
            this.panelProveedores.ResumeLayout(false);
            this.panelReportesFinancieros.ResumeLayout(false);
            this.panelControlUsuarios.ResumeLayout(false);
            this.panelConfiguracion.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel SidePanel;
        private System.Windows.Forms.PictureBox pictureBox1;
        /*private View.UserControlHabitaciones UserControlHabitaciones1;
        private View.ListadoReservaciones ListadoReservaciones;/********************************************/
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel ReservacionesDropDown;
        private System.Windows.Forms.Button btnRegistroHabitaciones;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button2;
        private View.UserControlInicio userControlInicio1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panelClientes;
        private System.Windows.Forms.Button btnListadoClientes;
        private System.Windows.Forms.Button btnRegistroHuesped;
        private System.Windows.Forms.Panel panelConfiguracion;
        private System.Windows.Forms.Button btnTipoRubroProveedores;
        private System.Windows.Forms.Button btnTipoHabitaciones;
        private System.Windows.Forms.Button btnTipoDocumento;
        private System.Windows.Forms.Button btnInformacionCompania;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button btnPermisosUsuarios;
        private System.Windows.Forms.Button btnConfigurarImpuestos;
        private System.Windows.Forms.Button btnConfigurarTipoCategoria;
        private System.Windows.Forms.Panel DropDownProductos;
        private System.Windows.Forms.Button btnRegistrarCompra;
        private System.Windows.Forms.Button btnVentasPorCategoria;
        private System.Windows.Forms.Button btnHistorialCompra;
        private System.Windows.Forms.Button btnListaProductos;
        private System.Windows.Forms.Panel panelReportesFinancieros;
        private System.Windows.Forms.Button btnImpuestos;
        private System.Windows.Forms.Button btnDescuentosRealizados;
        private System.Windows.Forms.Button btnFacturas;
        private System.Windows.Forms.Button btnReservacionesCanceladas;
        private System.Windows.Forms.Button btnIngresosDía;
        private System.Windows.Forms.Button btnResumenDía;
        private System.Windows.Forms.Button btnDescuentosRegistradosHoy;
        private System.Windows.Forms.Button btnEgresosDía;
        private System.Windows.Forms.Button btnDetallesIngresosExtras;
        private System.Windows.Forms.Button btnCuentasPorHospedaje;
        private System.Windows.Forms.Panel panelControlUsuarios;
        private System.Windows.Forms.Button btnNuevoEmpleado;
        private System.Windows.Forms.Button btnListadoEmpleados;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.Timer timer5;
        private System.Windows.Forms.Timer timer6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnRegistroProducto;
        private System.Windows.Forms.Panel panelProveedores;
        private System.Windows.Forms.Button btnListadoProveedores;
        private System.Windows.Forms.Button btnRegistroProveedores;
        private System.Windows.Forms.Button btnPuntoDeVenta;
        private System.Windows.Forms.Timer timer7;
    }
}

