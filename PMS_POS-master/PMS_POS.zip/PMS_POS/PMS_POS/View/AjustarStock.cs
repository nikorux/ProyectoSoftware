﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMS_POS.View
{
    public partial class AjustarStock : UserControl
    {
        public AjustarStock()
        {
            InitializeComponent();
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {

        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {

        }

        private void CbxUnidadMedida_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void CbxAccionAjuste_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
